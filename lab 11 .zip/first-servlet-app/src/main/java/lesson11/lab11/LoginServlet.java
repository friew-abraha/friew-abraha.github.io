package lesson11.lab11;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = req.getParameter("user_name");
        String password = req.getParameter("pass");
        String remember = req.getParameter("remember");
     //   boolean flag = (req.getParameter("rememberme")!null?true:false)
        HttpSession session = req.getSession();

        if("Friew".equals(userName) && "abc".equals(password)){
            session.setAttribute(  "user", userName);
            Cookie ck;
            if("yes".equals(remember)){
                ck = new Cookie("user", userName);
                ck.setMaxAge(30*24*60*60);
            }
            else {

                ck = new Cookie("user", null);
                ck.setMaxAge(0);
                resp.addCookie(ck);
            }

            resp.sendRedirect("welcome.jsp");
    } else{
            session.setAttribute("err.msg", "Username and/or password invalid");
            resp.sendRedirect("login");
         //   req.getRequestDispatcher("login").forward(req, resp);
        }
        PrintWriter out = resp.getWriter();





        out.print("<html><head><title>ViewPage</title></head>");
        out.print("<body><p>welcome " + userName);
        out.print("</p>");
        out.print("<form action='logout' method='POST'>");
        out.print("<input type='submit' value='log-out' />");
        out.print("</form></body></html>");
    }
}
