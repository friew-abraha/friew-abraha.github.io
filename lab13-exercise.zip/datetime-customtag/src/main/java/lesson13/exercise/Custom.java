package lesson13.exercise;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;


public class Custom extends SimpleTagSupport{
    private String color;
    private String size;
    private String text;

    @Override
    public void doTag() throws JspException, IOException{
        LocalDate dNow = LocalDate.now();
        DateTimeFormatter ft=DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy");
        JspWriter out = getJspContext().getOut();
        if(color != null && size != null) {

            out.write(String.format("<span style = 'color:%s; font-size:%s'>%s </span>", color, size, text+ft.format(dNow)));
        } else{
            out.write(String.format("<span>%s</span>", text));
        }
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSize(String size) {
        this.size = size;
    }
  public void setText(String text){
        this.text=text;
  }
}
